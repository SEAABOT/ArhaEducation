/* ARHA Education — site script
   1. Mobile menu  2. Enquiry form -> WhatsApp (and optional email via Web3Forms)
   3. Pre-select class from links like contact/?class=Class%209-10#enquire */
(function () {
  'use strict';

  // ---- Settings: edit here --------------------------------------------
  var WHATSAPP = '917069115571';          // country code + number, no "+"
  var WEB3FORMS_KEY = '';                 // optional: paste a key from web3forms.com to also receive enquiries by email
  // ----------------------------------------------------------------------

  // Mobile menu
  var btn = document.querySelector('.menu-btn');
  var panel = document.getElementById('mobile-nav');
  if (btn && panel) {
    btn.addEventListener('click', function () {
      var open = panel.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.querySelector('.label').textContent = open ? 'Close' : 'Menu';
    });
  }

  // Footer year
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // Enquiry form
  var form = document.getElementById('enquiry-form');
  if (!form) return;

  // Pre-fill class / interest from the URL
  try {
    var params = new URLSearchParams(window.location.search);
    var cls = params.get('class');
    var sel = form.querySelector('[name="class"]');
    if (cls && sel) {
      for (var i = 0; i < sel.options.length; i++) {
        if (sel.options[i].value === cls) { sel.selectedIndex = i; break; }
      }
    }
  } catch (e) { /* older browsers: ignore */ }

  function setError(name, bad) {
    var f = form.querySelector('[data-field="' + name + '"]');
    if (f) f.classList.toggle('invalid', bad);
    return bad;
  }

  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var d = {
      name: form.name.value.trim(),
      phone: form.phone.value.replace(/\D/g, ''),
      cls: form['class'].value,
      board: form.board.value,
      interest: form.interest.value,
      message: form.message.value.trim()
    };
    var bad = false;
    bad = setError('name', d.name.length < 2) || bad;
    bad = setError('phone', !/^[6-9]\d{9}$/.test(d.phone)) || bad;
    bad = setError('class', !d.cls) || bad;
    bad = setError('consent', !form.consent.checked) || bad;
    if (bad) {
      var first = form.querySelector('.invalid input, .invalid select');
      if (first) first.focus();
      return;
    }

    var lines = [
      'Hello ARHA Education, I would like to enquire about admission.',
      'Parent: ' + d.name,
      'Mobile: +91 ' + d.phone,
      'Class: ' + d.cls + (d.board ? ' (' + d.board + ')' : ''),
      d.interest ? 'Interested in: ' + d.interest : '',
      d.message ? 'Message: ' + d.message : ''
    ].filter(Boolean).join('\n');

    if (WEB3FORMS_KEY) {
      var body = new FormData();
      body.append('access_key', WEB3FORMS_KEY);
      body.append('subject', 'New enquiry from arhaeducation.in: ' + d.cls);
      body.append('message', lines);
      fetch('https://api.web3forms.com/submit', { method: 'POST', body: body }).catch(function () {});
    }

    if (window.gtag) window.gtag('event', 'generate_lead', { method: 'enquiry_form', class_name: d.cls });

    var ok = document.getElementById('form-success');
    if (ok) ok.classList.add('show');
    window.open('https://wa.me/' + WHATSAPP + '?text=' + encodeURIComponent(lines), '_blank', 'noopener');
  });

  // Clear an error as soon as the parent fixes it
  form.addEventListener('input', function (e) {
    var f = e.target.closest('[data-field]');
    if (f) f.classList.remove('invalid');
  });
})();
